<div id="brands-carousel" class="logo-slider wow fadeInUp">
		<h3 class="section-title">Our Brands</h3>
		<div class="logo-slider-inner">	
			<div id="brand-slider" class="owl-carousel brand-slider custom-carousel owl-theme">
				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/1.jpg" src="assets/images/blank.gif" alt="" style="width: 150px; height: 100px;">
					</a>	
				</div><!--/.item-->

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/2.jpg" src="assets/images/blank.gif" alt="" style="width: 150px; height: 100px;">
					</a>	
				</div><!--/.item-->

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/3.jpg" src="assets/images/blank.gif" alt="" style="width: 150px; height: 100px;">
					</a>	
				</div><!--/.item-->

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/4.png" src="assets/images/blank.gif" alt="" style="width: 150px; height: 100px;">
					</a>	
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/5.png" src="assets/images/blank.gif" alt=""style="width: 150px; height: 100px;">
					</a>	
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/6.png" src="assets/images/blank.gif" alt=""style="width: 150px; height: 100px;">
					</a>	
				</div>

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/7.png" src="assets/images/blank.gif" alt=""style="width: 150px; height: 100px;">
					</a>	
				</div>
<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/8.png" src="assets/images/blank.gif" alt=""style="width: 150px; height: 100px;">
					</a>	
				</div>
				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/9.png" src="assets/images/blank.gif" alt=""style="width: 150px; height: 100px;">
					</a>	
				</div>

				

				<div class="item">
					<a href="#" class="image">
						<img data-echo="brandsimage/10.png" src="assets/images/blank.gif" alt=""style="width: 150px; height: 100px;">
					</a>	
				</div>




		    </div><!-- /.owl-carousel #logo-slider -->
		</div><!-- /.logo-slider-inner -->
	
</div><!-- /.logo-slider -->