<div class="span3">
    <div class="sidebar">

        <ul class="widget widget-menu unstyled">
            <li>
                <a href="orders.php">
                    <i class="menu-icon icon-cog"></i>
                    Orders 
                </a>
</li>
<li>
                <a href="delivered-orders.php">
                    <i class="menu-icon icon-cog"></i>
                    Delivered Orders
                </a>
            <li>
</ul>

            <ul class="widget widget-menu unstyled">
                <li>
                <a href="manage-users.php">
                    <i class="menu-icon icon-group"></i>
                    Manage users
                </a>
            </li>
        </ul>

        <ul class="widget widget-menu unstyled">
            <li><a href="category.php"><i class="menu-icon icon-tasks"></i> Create Category </a></li>
            <li><a href="subcategory.php"><i class="menu-icon icon-tasks"></i> Sub Category </a></li>

</ul>
<ul class="widget widget-menu unstyled">
            <li><a href="insert-product.php"><i class="menu-icon icon-paste"></i> Insert Product </a></li>
            <li><a href="manage-products.php"><i class="menu-icon icon-table"></i> Manage Products </a></li>
        </ul><!--/.widget-nav-->

    </div><!--/.sidebar-->
</div><!--/.span3-->
