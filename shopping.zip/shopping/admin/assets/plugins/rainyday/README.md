rainyday.js
===========
A simple script for simulating raindrops falling on a glass surface.

For demos and more information see the [project page](http://maroslaw.github.io/rainyday.js/)

You might also consider subscribing to my [subreddit](http://www.reddit.com/r/rainydayjs/)

**Now added a configurable demo page**

opening demo.html?imgur=I2tZMAg&youtube=Ftu5ZpAk8dM will load [this image](http://imgur.com/I2tZMAg) with [this sound](http://youtu.be/Ftu5ZpAk8dM) in the background!

